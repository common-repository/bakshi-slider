<?php

echo " ";
?>

<div style="font-size:18px; color:#000066">Sumit bakshi is a great persnalty in india </br>
he is 22 year old and work in nanotechnology</br>
this is the first plugin buil by sumit bakshi</br>
all write reserved .

<b style="color:#000000">Bakshi Software limted</b></br>

Not just a name its a relation
</div>

