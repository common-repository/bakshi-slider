<?php
/*
Plugin Name: Bakshi Slider
Plugin URI: http://sumitbakshi.wordpress.com	
Description: Wordpress Slider plugin.
Version: 1.0
Author: Bakshi Technologies
Author URI: http://sumitbakshi.wordpress.com	
License: GPL2
Copyright YEAR 2011- 2050  (email : sumitbakshi88@gmail.com.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

/*****************Admin Section*************/
add_action('admin_menu', 'bakshi_slider_menu');
add_action('wp_enqueue_scripts','slider_scripts');

function slider_scripts()
{
	if(is_admin())
	{
	} else {
	
		wp_register_style( 'preview', WP_PLUGIN_URL . '/bakshi_slider/css/example2.css',false,false);
		wp_enqueue_style( 'preview' );

		wp_register_script( 'jquery-1.2.1.pack.js', WP_PLUGIN_URL . '/bakshi_slider/js/jquery-1.2.1.pack.js');
		wp_enqueue_script( 'jquery-1.2.1.pack.js' );
		wp_register_script( 'jcarousellite_1.0.1.min.js', WP_PLUGIN_URL . '/bakshi_slider/js/jcarousellite_1.0.1.min.js');
		wp_enqueue_script( 'jcarousellite_1.0.1.min.js' );
	}
}

function bakshi_slider_menu()
{
add_menu_page('Bakshi Slider', 'Bakshi Slider', 'administrator', 1, 'bakshi_slider_admin');
}

function bakshi_slider_admin()
{
	include "bakshi_slider_admin.php";
}

function showwpSlider($id)
{
	global $post;
	extract( shortcode_atts( array(
      'cat_id' => '0',     
      ), $atts ) );

	esc_attr($cat_id);
	
	$args = array('category' => $id, 'post_status' =>'publish');
	$myposts = get_posts($args);
	//echo "<pre>".print_r($myposts);
?>
<script type="text/javascript">		
jQuery(function() {
    jQuery(".jcarousellite").jCarouselLite({
        btnNext: ".next",
        btnPrev: ".prev",
		auto: 800,
	    speed: 1000
		
    });
});

	</script>
<div class="mainslider">
  <button class="prev"><img src="<?php echo WP_PLUGIN_URL; ?>/bakshi_slider/img/prev_new.png" alt="" /></button>

	<div class="jcarousellite">
		<ul>
<?php foreach( $myposts as $post ) : 
		 $output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
		 $first_img = $matches [1] [0];

		if(empty($first_img)){ //Defines a default image
			$first_img = WP_PLUGIN_URL."/bakshi_slider/img/default.gif";
		  }

		$content = $post->post_excerpt;
		if(empty($content))
		{
			$content = substr($post->the_content,0,100);
		}

		?>
			<li style="height:auto!important"><a href="<?php the_permalink();?>"><div class="divimg"><img src="<?php echo WP_PLUGIN_URL; ?>/bakshi_slider/scripts/timthumb.php?src=<?php echo $first_img; ?>&h=500&w=200&zc=1" width="20" height="500"></div><div class="title"><?php echo $post->post_title;?></div><div class="para"><?php echo $post->post_excerpt;?></div></a></li>
			
<?php endforeach; ?>
          </ul>		
	</div>
	<button class="next"><img src="<?php echo WP_PLUGIN_URL; ?>/bakshi_slider/img/next.png" alt="" /></button>
</div>
<?php
}
add_shortcode('wpslider', 'showwpSlider');

?>